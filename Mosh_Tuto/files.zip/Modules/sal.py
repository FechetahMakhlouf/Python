def fun_1():
    pass


def fun_2():
    pass
